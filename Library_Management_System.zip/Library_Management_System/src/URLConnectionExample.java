import java.net.HttpURLConnection;
import java.net.URL;
import java.net.InetAddress;
public class URLConnectionExample {
    public static void main(String[] args) {
        try {
            URL url = new URL("http://www.google.com"); 
            HttpURLConnection conn = (HttpURLConnection) url.openConnection(); 
            conn.setRequestMethod("GET"); 
            int responseCode = conn.getResponseCode(); 
            String responseMessage = conn.getResponseMessage();
            InetAddress ip;
            String hostname;
            ip = InetAddress.getLocalHost();
            hostname = ip.getHostName();
            System.out.println("My IP Address: " + ip);
            System.out.println("My Hostname: " + hostname);
            System.out.println("Request Method: " + conn.getRequestMethod());
            System.out.println("Response Code: " + responseCode);
            System.out.println("Response Message: " + responseMessage);
            conn.disconnect(); 
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
