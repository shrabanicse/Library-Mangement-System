-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Dec 04, 2022 at 06:42 AM
-- Server version: 10.4.24-MariaDB
-- PHP Version: 8.1.6

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `library_ms`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE `admin` (
  `id` int(11) NOT NULL,
  `name` varchar(50) DEFAULT NULL,
  `password` varchar(50) DEFAULT NULL,
  `email` varchar(100) DEFAULT NULL,
  `contact` varchar(20) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`id`, `name`, `password`, `email`, `contact`) VALUES
(1, 'tony', '123456', 'tony@gmail.com', '12345'),
(2, 'fahim', '56789', 'fahim@gmail.com', '23456'),
(3, 'riyad', '45678', 'riyad@gmail.com', '98765'),
(4, 'banner', '5555', 'banner@gmail.com', '34567'),
(5, 'johnny', '6666', 'johnny@gmail.com', '2345'),
(6, 'samad', '7777', 'samad@gmail.com', '6789'),
(7, 'saikat', '8888', 'saikat@gmail.com', '34567'),
(8, 'shrabani', '4567', 'shrabani@gmail.com', '34567'),
(12, 'tina', 'tina456', 'tina45@yahoo.com', '176420'),
(13, 'hasan', 'hasan345', 'hasan@gmail.com', '45678'),
(14, 'Masum', '567', 'Masum@gmail.com', '46546'),
(15, 'poly', 'poly123', 'poly@gmail.com', '12345'),
(16, 'moly', 'moly67', 'moly@gmail.com', '3456'),
(17, 'joly', 'joly123', 'joly@gmail.com', '3456'),
(18, 'liakot', 'li456', 'likot@gmail.com', '34567'),
(19, 'sarkit', 'sar456', 'sar@gmail.com', '12345'),
(20, 'Mohammad Ali', 'Ali007', 'Ali@gmail.com', '34567'),
(21, 'admin', '12345', 'admin@gmail.com', '45678'),
(22, 'fahim', 'fahim345', 'fahim@gmail.com', '345678'),
(23, 'farhan', 'far234', 'far@gmail.com', '34567'),
(24, 'Tina', 'Tina678', 'Tina@gmail.com', '23456'),
(25, 'xd', '45', 'sese@gmail.com', '544');

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `bookID` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `publisher` varchar(100) DEFAULT NULL,
  `price` varchar(10) DEFAULT NULL,
  `publisherYear` varchar(10) DEFAULT NULL,
  `bLocation` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`bookID`, `name`, `publisher`, `price`, `publisherYear`, `bLocation`) VALUES
('1', 'javascript', 'Dennis Ritchie', '300', '2010', 'col-1,row-2'),
('10', 'Go Programming', 'James Kahn', '800', '2020', 'col-4,row-6'),
('100', 'System Analysis', 'Kenneth Kendall', '500', '2012', 'Col-2, Row-6,Shelf-8'),
('2', 'English Grammar', 'John Olivander', '250', '2014', 'col-1,row-4'),
('3', 'python', 'Jack Ryan', '390', '2017', 'col-3,row-3'),
('4', 'C Programming', 'Alec Baldwin', '200', '2019', 'col-2,row-8'),
('5', 'c++ Program', 'Charles Dier', '400', '2018', 'col-1,row-5'),
('6', 'java programming', '2019', '280', '2018', 'col-3,row-10'),
('7', 'math book', 'Ryan Gosling', '400', '2019', 'col-3,row-9'),
('8', 'Poetry', 'John Doe', '400', '2018', 'col-3,row-7'),
('9', 'Rust Programming', 'Micheal Harris', '360', '2019', 'col-4,row-9');

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE `issue` (
  `bookID` varchar(100) DEFAULT NULL,
  `studentID` varchar(100) DEFAULT NULL,
  `issueDate` varchar(20) DEFAULT NULL,
  `dueDate` varchar(20) DEFAULT NULL,
  `returnBook` varchar(10) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `issue`
--

INSERT INTO `issue` (`bookID`, `studentID`, `issueDate`, `dueDate`, `returnBook`) VALUES
('1', '1', '06-07-2022', '10-07-2022', 'YES'),
('2', '2', '07-07-2022', '15-07-2022', 'YES'),
('4', '4', '09-07-2022', '15-07-2022', 'YES'),
('4', '5', '11-07-2022', '18-07-2022', 'YES'),
('4', '1', '10-07-2022', '16-07-2022', 'YES'),
('5', '7', '16-07-2022', '20-07-2022', 'YES'),
('6', '3', '18-07-2022', '28-07-2022', 'No'),
('7', '8', '20-07-2022', '30-07-2022', 'YES'),
('8', '10', '19-07-2022', '28-07-2022', 'YES'),
('9', '11', '18-07-2022', '22-07-2022', 'YES'),
('10', '12', '18-07-2022', '21-07-2022', 'YES'),
('30', '78', '23-07-2022', '29-07-2022', 'No'),
('12', '85', '25-07-2022', '30-07-2022', 'YES'),
('15', '86', '26-07-2022', '30-07-2022', 'YES'),
('23', '90', '26-07-2022', '30-07-2022', 'YES'),
('6', '55', '27-07-2022', '30-07-2022', 'YES'),
('6', '55', '27-07-2022', '10-08-2022', 'YES'),
('50', '101', '27-07-2022', '20-08-2022', 'YES'),
('5', '90', '30-07-2022', '15-08-2022', 'No'),
('4', '90', '30-07-2022', '18-08-2022', 'YES'),
('2', '90', '30-07-2022', '25-08-2022', 'YES'),
('7', '60', '30-07-2022', '22-08-2022', 'YES'),
('8', '60', '30-07-2022', '16-08-2022', 'No'),
('78', '67', '10-08-2022', '19-08-2022', 'YES'),
('50', '19203103049', '12-08-2022', '24-08-2022', 'YES'),
('4', '19203103049', '11-08-2022', '17-08-2022', 'YES'),
('3', '60', '11-08-2022', '25-08-2022', 'No'),
('68', '19203103078', '12-11-2022', '20-11-2022', 'No'),
('1', '19203103049', '04-12-2022', '14-12-2022', 'No'),
('2', '19203103078', '05-12-2022', '15-12-2022', 'No'),
('3', '19203103082', '05-12-2022', '10-12-2022', 'No'),
('4', '19203103040', '06-12-2022', '15-12-2022', 'No'),
('5', '19203103045', '07-12-2022', '15-12-2022', 'No'),
('5', '19203103061', '07-12-2022', '09-12-2022', 'No'),
('6', '19203103057', '08-12-2022', '15-12-2022', 'YES'),
('7', '19203103035', '08-12-2022', '16-12-2022', 'YES'),
('8', '19203103050', '07-12-2022', '17-12-2022', 'YES');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `studentID` varchar(100) NOT NULL,
  `name` varchar(100) DEFAULT NULL,
  `fatherName` varchar(100) DEFAULT NULL,
  `section` varchar(10) NOT NULL,
  `class` varchar(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`studentID`, `name`, `fatherName`, `section`, `class`) VALUES
('1', 'Fardin Khan', 'Mr.Raisul Khan', '1', '9'),
('10', 'Razi Rafid', 'Mr.Arif Hossain', '2', '7'),
('101', 'Mostfizur Islam', 'Mr riyad Hossain', '3', '4'),
('102', 'Amdadul Islam', 'Mr Jubayer Ahmed', '3', '7'),
('103', 'Badhon Das', 'Mr Tonmoy Das', '3', '7'),
('104', 'Soumya Sarkar', 'Mr Kreshan Sarkar', '2', '9'),
('105', 'Ratna Islam', 'Mr Anisul Khan', '2', '5'),
('106', 'Arisha Khan', 'Mr Hanif Khan', '3', '6'),
('11', 'Rafid Khan', 'Mr. Hasan Iqbal', '1', '10'),
('12', 'Zerin Khan', 'Mr. Tarik', '2', '6'),
('13', 'Hasan Islam', 'Mr. Jahangir Islam', '3', '10'),
('14', 'Abir Islam', 'Mr Raisul Islam', '3', '7'),
('15', 'Trisha Khan', 'Mr Halim Khan', '3', '9'),
('16', 'Polash Islam', 'Mr Rimon Islam', '2', '7'),
('17', 'Jubayer Islam', 'Mr Kamrul Islam', '2', '5'),
('18', 'Umme Kulsum', 'Mr Rahat Bari', '3', '8'),
('1820394757', 'Jahanara Islam', 'Mr. Anisul Islam', '2', ''),
('1833045678', 'Raisul Islam', 'Mr. Hasan Khan', '2', ''),
('19', 'Fardin Islam', 'Mr Rifat Islam', '2', '6'),
('19203103035', 'Rafid Haque', 'Mr. Ahsanul Islam', '1', ''),
('19203103040', 'Naim Hasan', 'Mr. Kabir Khan', '1', ''),
('19203103045', 'Rifat Ara', 'Mr. Akib Islam', '1', ''),
('19203103046', 'Jubayer Islam', 'Mr. Shahidul Alam', '2', ''),
('19203103049', 'Fahim Imran', 'Mr.Abdul Khaleque', '2', ''),
('19203103050', 'Siam Hossain', 'Mr. Abul Kalam', '3', ''),
('19203103057', 'Riyad Hossain', 'Mr. Kamal Hossain', '1', ''),
('19203103061', 'Tuhin Khan', 'Mr. Jahangir Alam', '3', ''),
('19203103078', 'Shrabani Das', 'Mr.Milon Das', '2', ''),
('19203103082', 'Bayzid Simon Sarkar', 'John Francis Sarkar', '2', ''),
('2', 'Barsha Islam', 'Mr.Farid Islam', '2', '8'),
('20', 'Firoz Khan', 'Mr Arif Khan', '3', '9');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin`
--
ALTER TABLE `admin`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`bookID`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`studentID`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin`
--
ALTER TABLE `admin`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=26;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
